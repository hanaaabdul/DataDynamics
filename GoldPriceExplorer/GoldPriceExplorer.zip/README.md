# Gold Price Trends Explorer

A beginner-friendly project exploring real gold price data using Python.

## How to Run

### 1. Install Python
Download from: https://www.python.org/

### 2. Install required libraries
Run this in your terminal:

```
pip install pandas matplotlib yfinance
```

### 3. Run the analysis script
Navigate to the project folder in your terminal:

```
python analysis.py
```

### What the script does:
- Loads gold price data (past 5 years)
- Computes basic statistics (mean, max, min, volatility)
- Plots price trend + moving average
