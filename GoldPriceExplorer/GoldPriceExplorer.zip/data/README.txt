Place optional gold_prices.csv here if you download it manually.
